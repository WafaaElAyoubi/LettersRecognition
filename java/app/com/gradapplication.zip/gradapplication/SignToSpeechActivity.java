package app.com.gradapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CameraMetadata;
import android.hardware.camera2.CaptureRequest;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.util.Log;
import android.view.SurfaceView;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import org.opencv.android.BaseLoaderCallback;
import org.opencv.android.CameraBridgeViewBase;
import org.opencv.android.JavaCameraView;
import org.opencv.android.LoaderCallbackInterface;
import org.opencv.android.OpenCVLoader;
import org.opencv.core.Core;
import org.opencv.core.CvType;
import org.opencv.core.Mat;
import org.opencv.core.MatOfInt;
import org.opencv.core.MatOfInt4;
import org.opencv.core.MatOfPoint;
import org.opencv.core.Point;
import org.opencv.core.Scalar;
import org.opencv.core.Size;
import org.opencv.imgproc.Imgproc;
import org.opencv.imgproc.Moments;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import static java.lang.Math.abs;

public class SignToSpeechActivity extends AppCompatActivity implements
    CameraBridgeViewBase.CvCameraViewListener2 {

        ImageView speech,back;
        private static String TAG = "MainActivity";
        JavaCameraView javaCameraView;
        TextToSpeech t1;


        static private double[][] values =
                {
                        {69	,78	,100,85},
                        {56	,88,100,90},
                        {80,100,89,	73},
                        {78,100,90,72},
                        {62,82,100,89}, //B

                        {48,	100	,52,	48},
                        {180	,100	,79	},
                        {70	,100,	60	}, //D

                        {52	,100	,94	,74,	58},
                        {109	,100	,78	,0	,0},
                        {107	,100,	78,	0	,0},
                        {58	,100	,77	,39,	0},
                        {126,	100	,53	,0,	0}, //F

                        {80	,100	,76,	75,	66},
                        {79	,100,	74	,74,	71},
                        {79	,83,100,	72,	79},
                        {80	,100	,76	,77,	69},
                        {80,	100	,76,	75,	66},
                        //A

                        {92	,100,	50,	41,	0},
                        {156,	65,	100,	0,	0},
                        {188	,100,	91,	0,	0}, //V

                        {92,	100	,64},
                        {84,	100	,51},
                        {89,	100	,52,	51},
                        {98,	100	,61,	49},
                        {93,	100	,60,	56}, //L

                        {104	,100}, //y

                        {54,	61,	100,	40},
                        {56,	58,	64,	100},
                        {66,	100,	48},
                        {56,	68,	100,44,	53}, //I

                        {111,	100,	90,76,	59},
                        {111,	82,	56,	100,	0},
                        {106,	84,	52,	100,	0},
                        {121,	100,	90,	80,	73},
                        { 142	,84,	87,	89,	100} //Q


                };


        static private double[][] LValues = {

                {121, 100},
                {123, 100, 31},
                {149, 100, 45},
                {122, 100, 33}
        };





        static private String[] alphabetValues = new String[values.length];
        ArrayList<Double> valueFingers;
        ArrayList<Double> valueBetweenFingers;
        ArrayList<Integer> valueFingersAns ;
        ArrayList<Integer> valueBetweenFingersAns ;
        private String gesture = "";

        private static final int CAMERA_PERMISSION_CODE = 100;

        Mat mRgba, hsvMat, hsvMatApplied, contourMat, lines;
        private static final int MAX_POINTS = 40;
        private int contourAxisAngle;
        private Point cogPt = new Point(); // center of gravity (COG) of contour
        private ArrayList<Point> fingerTips = new ArrayList<Point>();
        private Point[] tipPts, endPts, foldPts;
        private float[] depths;
        private int division = 50;

        private static final int MAX_FINGER_ANGLE = 300; // degrees
        private static final int MIN_FINGER_ANGLE = 8; // degrees
        private static final int MAX_FINGER_DISTANCE = 20;
        /*
         *
         */


        BaseLoaderCallback mLoaderCallBack = new BaseLoaderCallback(this) {
            @Override
            public void onManagerConnected(int status) {
                switch (status) {
                    case BaseLoaderCallback.SUCCESS: {
                        javaCameraView.enableView();
                        break;
                    }
                    default: {
                        super.onManagerConnected(status);
                        break;
                    }
                }
            }
        };


        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_sign_to_speech);

            checkPermission(
                    Manifest.permission.CAMERA,
                    CAMERA_PERMISSION_CODE);


            speech = (ImageView) findViewById(R.id.speech);
            back = (ImageView) findViewById(R.id.back);

            speech.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent = new Intent(SignToSpeechActivity.this, SpeechToSignActivity.class);
                    startActivity(intent);
                }
            });

            back.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    finish();

                }
            });

            t1=new TextToSpeech(getApplicationContext(), new TextToSpeech.OnInitListener() {
                @Override
                public void onInit(int status) {
                    if(status != TextToSpeech.ERROR) {
                        t1.setLanguage(Locale.ENGLISH);
                    }
                }
            });

            javaCameraView = (JavaCameraView)findViewById(R.id.java_camera_view);
            javaCameraView.setVisibility(SurfaceView.VISIBLE);
            javaCameraView.setCvCameraViewListener(this);


        }

        // Function to check and request permission
        public void checkPermission(String permission, int requestCode)
        {

            // Checking if permission is not granted
            if (ContextCompat.checkSelfPermission(
                    SignToSpeechActivity.this,
                    permission)
                    == PackageManager.PERMISSION_DENIED) {
                ActivityCompat
                        .requestPermissions(
                                SignToSpeechActivity.this,
                                new String[] { permission },
                                requestCode);
            }
            else {
                Toast
                        .makeText(SignToSpeechActivity.this,
                                "Permission already granted",
                                Toast.LENGTH_SHORT)
                        .show();
            }
        }


        @Override
        public void onWindowFocusChanged(boolean hasFocas) {
            super.onWindowFocusChanged(hasFocas);
            View decorView = getWindow().getDecorView();
            if(hasFocas) {
                decorView.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION);
            }
        }

        private void extractContourInfo(MatOfPoint bigContour, int scale) {
            Moments moments = Imgproc.moments(bigContour);

            // Centre of gravity
            double m00 = moments.m00;
            double m10 = moments.m10;
            double m01 = moments.m01;

            if (m00 != 0) { // calculate center
                double xCenter = Math.round(m10 / m00) * scale;
                double yCenter = Math.round(m01 / m00) * scale;
                cogPt.x = xCenter;
                cogPt.y = yCenter;
            }

            double m11 = moments.m11;
            double m20 = moments.m20;
            double m02 = moments.m02;
            contourAxisAngle = calculateTilt(m11, m20, m02);

            // deal with hand contour pointing downwards
            /*
             * uses fingertips information generated on the last update of the
             * hand, so will be out-of-date
             */

            if (fingerTips.size() > 0) {
                int yTotal = 0;
                for (Point pt : fingerTips)
                    yTotal += pt.y;
                int avgYFinger = yTotal / fingerTips.size();
                if (avgYFinger > cogPt.y) // fingers below COG
                    contourAxisAngle += 180;
            }
            contourAxisAngle = 180 - contourAxisAngle;
            /*
             * this makes the angle relative to a positive y-axis that runs up
             * the screen
             */
        } // end of extractContourInfo()

        private int calculateTilt(double m11, double m20, double m02) {
            double diff = m20 - m02;
            if (diff == 0) {
                if (m11 == 0)
                    return 0;
                else if (m11 > 0)
                    return 45;
                else // m11 < 0
                    return -45;
            }

            double theta = 0.5 * Math.atan2(2 * m11, diff);
            int tilt = (int) Math.round(Math.toDegrees(theta));

            if ((diff > 0) && (m11 == 0))
                return 0;
            else if ((diff < 0) && (m11 == 0))
                return -90;
            else if ((diff > 0) && (m11 > 0)) // 0 to 45 degrees
                return tilt;
            else if ((diff > 0) && (m11 < 0)) // -45 to 0
                return (180 + tilt); // change to counter-clockwise angle
            else if ((diff < 0) && (m11 > 0)) // 45 to 90
                return tilt;
            else if ((diff < 0) && (m11 < 0)) // -90 to -45
                return (180 + tilt); // change to counter-clockwise angle

            System.out.println("Error in moments for tilt angle");
            return 0;
        } // end of calculateTilt()

        private void findFingerTips(MatOfPoint approxContour, int scale) {

            MatOfInt hull = new MatOfInt();

            Imgproc.convexHull(approxContour, hull, false);
            // find the convex hull around the contour

            MatOfInt4 defects = new MatOfInt4();
            Imgproc.convexityDefects(approxContour, hull, defects);

            int defectsTotal = (int) defects.total();
            if (defectsTotal > MAX_POINTS) {
                defectsTotal = MAX_POINTS;
            }

            tipPts = new Point[defectsTotal];
            endPts = new Point[defectsTotal];
            foldPts = new Point[defectsTotal];
            depths = new float[defectsTotal];
            // copy defect information from defects sequence into arrays
            for (int i = 0; i < defectsTotal; i++) {
                double[] dat = defects.get(i, 0);

                double[] startdat = approxContour.get((int) dat[0], 0);
                Point startPt = new Point(startdat[0], startdat[1]);
                tipPts[i] = startPt;
                // array contains coords of the fingertips

                double[] enddat = approxContour.get((int) dat[1], 0);
                Point endPt = new Point(enddat[0], enddat[1]);
                endPts[i] = endPt;

                double[] depthdat = approxContour.get((int) dat[2], 0);
                Point depthPt = new Point(depthdat[0], depthdat[1]);
                foldPts[i] = depthPt;
                // array contains coords of the skin fold between fingers

                depths[i] = (float) dat[3];
                // array contains distances from tips to folds
            }

            reduceTips(defectsTotal, tipPts, endPts, foldPts, depths);
        } // end of findFingerTips()

        private void reduceTips(int numPoints, Point[] tipPts, org.opencv.core.Point[] endPts, org.opencv.core.Point[] foldPts, float[] depths) {
            fingerTips.clear();

            int n = 0;
            for (int i = 0; i < numPoints; i++) {

                if (i > 0) {
                    if ((abs(tipPts[i].x - tipPts[i - 1].x)) < MAX_FINGER_DISTANCE
                            && (abs(tipPts[i].y - tipPts[i - 1].y) < MAX_FINGER_DISTANCE)) {
                        continue;
                    }
                }
                if (i == (numPoints - 1)) {
                    if ((abs(tipPts[numPoints - 1].x - tipPts[0].x)) < MAX_FINGER_DISTANCE
                            && (abs(tipPts[numPoints - 1].y - tipPts[0].y) < MAX_FINGER_DISTANCE)) {
                        continue;
                    }
                }

                if (tipPts[i].x < mRgba.width() / division) {
                    continue;
                }
                if (tipPts[i].x > (division - 1) * mRgba.width() / division) {
                    continue;
                }
                int angle = 0;
                if (fingerTips.size() == 0 && i >0) {
                    angle = angle(tipPts[i], tipPts[i-1]);

                }

                else if (fingerTips.size() != 0) {
                    angle = angle(tipPts[i], fingerTips.get(fingerTips.size()-1));

                }

                if (angle >= MAX_FINGER_ANGLE)
                    continue;

                if (angle < MIN_FINGER_ANGLE)
                    continue;      // angle between finger and folds too wide
//            //  ans.append(" "+angle);
//
                if((cogPt.x - tipPts[i].x) <-10){
                    continue;
                }




                fingerTips.add(tipPts[i]);
                n++;

            }
//        ans.append("\n");
//        ans.append("\n");
//        ans.append("\n");


            // ans.append("\n");

        } // end of reduceTips()

        private int angle(org.opencv.core.Point tip, org.opencv.core.Point prev)

        {
            return abs((int) Math.round(Math.toDegrees(
                    Math.atan2(tip.x, tip.y )-
                            Math.atan2(prev.x, prev.y )
            )));
        }

        @Override
        protected void onPause() {
            super.onPause();
            if (javaCameraView != null) {
                javaCameraView.disableView();
            }
        }

        @Override
        protected void onDestroy() {
            super.onDestroy();
            if (javaCameraView != null) {
                javaCameraView.disableView();
            }
        }

        @Override
        protected void onResume() {
            super.onResume();
            if (OpenCVLoader.initDebug()) {
                Log.i(TAG, "OpenCV Loaded Successfully");
                mLoaderCallBack.onManagerConnected(LoaderCallbackInterface.SUCCESS);
            }
            else {
                Log.i(TAG, "OpenCV Not Loaded Successfully");
                OpenCVLoader.initAsync(OpenCVLoader.OPENCV_VERSION_3_2_0, this, mLoaderCallBack);
            }
        }

        @Override
        public void onCameraViewStarted(int width, int height) {
            mRgba = new Mat(height, width, CvType.CV_8UC4);
            hsvMat = new Mat(height, width, CvType.CV_8UC4);
            hsvMatApplied = new Mat(height, width, CvType.CV_8UC4);
            contourMat = new Mat(hsvMatApplied.rows(), hsvMatApplied.cols(), CvType.CV_8UC1);

        }

        @Override
        public void onCameraViewStopped() {
            mRgba.release();
            contourMat.release();
        }

        int timer =0;

        @Override
        public Mat onCameraFrame(CameraBridgeViewBase.CvCameraViewFrame inputFrame) {

            mRgba = inputFrame.rgba();

            Mat mRgbaT = mRgba.t();
            Core.flip(mRgba.t(), mRgbaT, 1);
            Imgproc.resize(mRgbaT, mRgbaT, mRgba.size());

//        Size sz = new Size(394,700);
//        Imgproc.resize(mRgba, mRgba, sz);
            Imgproc.blur(mRgba, mRgba, new Size(7, 7));
            Imgproc.cvtColor(mRgba, hsvMat, Imgproc.COLOR_BGR2HSV);

            Scalar hsvMin = new Scalar(100, 15, 105);
            Scalar hsvMax = new Scalar(138, 147, 237);



            double minHue, minSaturation, minValue, maxHue, maxSaturation, maxValue, tempHue = 30, tempSaturation = 80, tempValue = 100;

            if (hsvMat.get(mRgba.height()/2, mRgba.width()/2)[0] > tempHue) {
                minHue = hsvMat.get(mRgba.height()/2, mRgba.width()/2)[0] - tempHue;
            }
            else {
                minHue = hsvMat.get(mRgba.height()/2, mRgba.width()/2)[0];
            }
            if (hsvMat.get(mRgba.height()/2, mRgba.width()/2)[1] > tempSaturation) {
                minSaturation = hsvMat.get(mRgba.height()/2, mRgba.width()/2)[1] - tempSaturation;
            }
            else {
                minSaturation = hsvMat.get(mRgba.height()/2, mRgba.width()/2)[1];
            }
            if (hsvMat.get(mRgba.height()/2, mRgba.width()/2)[2] > tempValue) {
                minValue = hsvMat.get(mRgba.height()/2, mRgba.width()/2)[2] - tempValue;
            }
            else {
                minValue = hsvMat.get(mRgba.height()/2, mRgba.width()/2)[2];
            }
            if (hsvMat.get(mRgba.height()/2, mRgba.width()/2)[0] < (255 - tempHue)) {
                maxHue = hsvMat.get(mRgba.height()/2, mRgba.width()/2)[0] + tempHue;
            }
            else {
                maxHue = hsvMat.get(mRgba.height()/2, mRgba.width()/2)[0];
            }
            if (hsvMat.get(mRgba.height()/2, mRgba.width()/2)[1] < (255 - tempSaturation)) {
                maxSaturation = hsvMat.get(mRgba.height()/2, mRgba.width()/2)[1] + tempSaturation;
            }
            else {
                maxSaturation = hsvMat.get(mRgba.height()/2, mRgba.width()/2)[1];
            }
            if (hsvMat.get(mRgba.height()/2, mRgba.width()/2)[2] < (255 - tempValue)) {
                maxValue = hsvMat.get(mRgba.height()/2, mRgba.width()/2)[2] + tempValue;
            }
            else {
                maxValue = hsvMat.get(mRgba.height()/2, mRgba.width()/2)[2];
            }

//        Scalar hsvMin = new Scalar(minHue, minSaturation, minValue);
//        Scalar hsvMax = new Scalar(maxHue, maxSaturation, maxValue);

            Core.inRange(hsvMat, hsvMin, hsvMax, hsvMatApplied);

            Imgproc.blur(hsvMatApplied, hsvMatApplied, new Size(1, 1));
            Mat dilateElement = Imgproc.getStructuringElement(Imgproc.MORPH_RECT, new Size(1, 1));
            Mat erodeElement = Imgproc.getStructuringElement(Imgproc.MORPH_RECT, new Size(1, 1));

            Imgproc.erode(hsvMatApplied, hsvMatApplied, erodeElement);
            Imgproc.dilate(hsvMatApplied, hsvMatApplied, dilateElement);
            Imgproc.blur(hsvMatApplied, hsvMatApplied, new Size(1, 1));

            contourMat = new Mat(hsvMatApplied.rows(), hsvMatApplied.cols(), CvType.CV_8UC1);

            // MatOfPoint contourMat = new MatOfPoint();
            List<MatOfPoint> contours = new ArrayList<MatOfPoint>();
            Mat hierarchy = new Mat();
            Imgproc.findContours(hsvMatApplied, contours, hierarchy, Imgproc.RETR_LIST, Imgproc.CHAIN_APPROX_SIMPLE);

            double maxVal = 0;
            int maxValIdx = 0;

            for (int contourIdx = 0; contourIdx < contours.size(); contourIdx++) {
                double contourArea = Imgproc.contourArea(contours.get(contourIdx));
                if (maxVal < contourArea) {
                    maxVal = contourArea;
                    maxValIdx = contourIdx;
                }
            }

            Imgproc.drawContours(contourMat, contours, maxValIdx, new Scalar(255, 255, 255), -1);


            if (maxValIdx > 0) {

                MatOfPoint bigContour = contours.get(maxValIdx);

                extractContourInfo(bigContour, 1);
                // find the COG and angle to horizontal of the contour


                findFingerTips(bigContour, 1);
                // detect the fingertips positions in the contour

                for (int i = 0; i < alphabetValues.length; i++) {
                    if (i < 5) {
                        alphabetValues[i] = "B";
                    } else if (i >= 5 && i < 8) {
                        alphabetValues[i] = "D";
                    }
                    else if(i>=8 && i<13){
                        alphabetValues[i] = "F";

                    }
                    else if(i>=13 && i<18){
                        alphabetValues[i] = "A";

                    }

                    else if(i>=18 && i<23){
                        alphabetValues[i] = "V";

                    }
                    else if(i>=23 && i <28){
                        alphabetValues[i] = "L";

                    }
                    else if(i==28){
                        alphabetValues[i] = "Y";

                    }
                    else if(i>=29 && i<34){
                        alphabetValues[i] = "I";

                    }
                    else if(i>=34 && i<39){
                        alphabetValues[i] = "Q";

                    }

                }


//            valueFingers = new double[fingerTips.size()];
//            valueBetweenFingers = new double[fingerTips.size()];

                valueFingers = new ArrayList<Double>(fingerTips.size());
                valueFingersAns = new ArrayList<Integer>();
                valueBetweenFingersAns = new ArrayList<Integer>();
                valueBetweenFingers = new ArrayList<Double>(fingerTips.size());

                lines = mRgba;
                if (contourMat.height() > 0 && contourMat.width() > 0 && fingerTips.size() != 0) {
                    for (int i = 0; i < fingerTips.size(); i++) {

                        Point pt1 = fingerTips.get(i);
                        if (i > 0) {
                            Point pt2 = fingerTips.get(i - 1);
                            valueBetweenFingers.add((Math.sqrt(Math.pow((pt1.x - pt2.x), 2) + Math.pow((pt1.y - pt2.y), 2))));
                            //Log.i("Myapp", Integer.toString(i - 1) + "   " + Integer.toString((int)valueBetweenFingers[i - 1]) + "+");
                        }
                        //System.out.println("Myapp" + "  " + Integer.toString(i) + "   " + Double.toString(abs(valueFingers[i])));
                    }
                }

                double max = 0;

                for (int i = 1; i < valueBetweenFingers.size(); i++) {
                    if (valueBetweenFingers.get(i) > max) {
                        max = valueBetweenFingers.get(i);
                    }
                }
                int num;
                if (valueBetweenFingers.size() != 0) {

                    num = (int) ((valueBetweenFingers.get(0) / max) * 100);
                    //  ans.append(num+" ");
                    valueBetweenFingers.set(0, (double) num);
                    valueBetweenFingersAns.add(num);

                    for (int i = 1; i < valueBetweenFingers.size(); i++) {
                        num = (int) ((valueBetweenFingers.get(i) / max) * 100);

                        // ans.append(num + " ");
                        valueBetweenFingers.set(i, (double) num);
                        valueBetweenFingersAns.add(num);
                    }

                    if (contourMat.height() > 0 && contourMat.width() > 0 && fingerTips.size() != 0) {
                        for (int i = 0; i < fingerTips.size(); i++) {

                            Point center = new Point(mRgba.width() / 2, mRgba.height() / 2);
                            Imgproc.circle(lines, center, 5, new Scalar(0, 0, 0));
                            Point pt1 = fingerTips.get(i);

                            if (i > 0) {
                                Point pt2 = fingerTips.get(i - 1);

                                if ((valueBetweenFingersAns.get(i - 1) < -5) || ((valueBetweenFingersAns.get(i - 1)) > 5)) {

                                    Imgproc.line(lines, pt2, pt1, new Scalar(0, 255, 0), 2);

                                } else {
                                    continue;
                                }

                                //Log.i("Myapp", Integer.toString(i - 1) + "   " + Integer.toString((int)valueBetweenFingers[i - 1]) + "+");
                            }
                            Imgproc.line(lines, cogPt, pt1, new Scalar(255, 0, 0), 4);
                            Imgproc.circle(lines, pt1, 16, new Scalar(255, 204, 0));
                            valueFingers.add((Math.sqrt(Math.pow((pt1.x - cogPt.x), 2) + Math.pow((pt1.y - cogPt.y), 2))));
                            //System.out.println("Myapp" + "  " + Integer.toString(i) + "   " + Double.toString(abs(valueFingers[i])));
                        }
                        Imgproc.circle(lines, cogPt, 90, new Scalar(0, 0, 255));
                    }

                    double max2 = 0;

                    for(int i = 1; i < valueFingers.size();i++)
                    {
                        if(valueFingers.get(i) > max2)
                        {
                            max2 = valueFingers.get(i);
                        }
                    }

                    int num2;


                    num2 =(int)((valueFingers.get(0)/max2)*100);
                    //valueFingers.set(0, (double) num2);
                    valueFingersAns.add(num2);

                    for(int i =1 ; i<valueFingers.size();i++) {
                        num2 = (int) ((valueFingers.get(i) / max2) * 100);
                        //   if (((valueFingers.get(i - 1) - num) > 10) || ((valueFingers.get(i - 1) - num) < -10)) {
                        //valueFingers.set(i, (double) num2);
                        valueFingersAns.add(num2);
                    }


//            if(((Math.sqrt(Math.pow((pt1.x - pt2.x), 2) + Math.pow((pt1.y - pt2.y), 2))) < 10 ) || ((Math.sqrt(Math.pow((pt1.x - pt2.x), 2) + Math.pow((pt1.y - pt2.y), 2))) > -10))
//                continue;

//            double max = 0;
//
//            for(int i = 1; i < valueFingers.size();i++)
//            {
//                if(valueFingers.get(i) > max)
//                {
//                    max = valueFingers.get(i);
//                }
//            }
//
//            int num;
//
//            num =(int)((valueFingers.get(0)/max)*100);
//            ans.append(num+" ");
//            valueFingers.set(0, (double) num);
//            valueFingersAns.add(num);
//
//            for(int i =1 ; i<valueFingers.size();i++) {
//                num = (int) ((valueFingers.get(i) / max) * 100);
//             //   if (((valueFingers.get(i - 1) - num) > 10) || ((valueFingers.get(i - 1) - num) < -10)) {
//                    ans.append(num + " ");
//                    valueFingers.set(i, (double) num);
//                    valueFingersAns.add(num);
////                }
////                else {
////                    valueFingers.set(i, (double) num);
////
////                }
//            }


                    // ans.append("\nEnd\n");

//            num =(int)((valueBetweenFingers.get(0)/max)*100);
//            ans.append(num+" ");
//            valueBetweenFingers.set(0, (double) num);
//            valueBetweenFingersAns.add(num);
//
//            for(int i =1 ; i<valueBetweenFingers.size();i++) {
//                num = (int) ((valueBetweenFingers.get(i) / max) * 100);
//               // if ((((valueBetweenFingers.get(i - 1) - num) > 10) || ((valueBetweenFingers.get(i - 1) - num) < -10))&& (((valueBetweenFingers.get(i - 1) - num) > -40)||((valueBetweenFingers.get(i - 1) - num) < 40))) {
//                    ans.append(num + " ");
//                    valueBetweenFingers.set(i, (double) num);
//                    valueBetweenFingersAns.add(num);
//              //  }
////                else {
////                    valueBetweenFingers.set(i, (double) num);
////
////                }
//            }


                }
            }


            if(timer == 30) {
                runOnUiThread(new Runnable() {
                    public void run() {
                        String answer = " ";
                        for (int i = 0; i < values.length; i++) {
                            boolean same = true;
                            if(valueFingersAns.size() <= values[i].length) {
                                for (int j = 0; j < valueFingersAns.size(); j++) {
                                    if (valueFingersAns.get(j) <= (values[i][j] + 20) && valueFingersAns.get(j) >= (values[i][j] - 20)) {
                                        same &= true;
                                    } else {
                                        same &= false;
                                    }
                                }
                            }


                            answer = alphabetValues[i];
                            if (same == true && alphabetValues[i].equals("D")){

                                for (int a = 0; a < LValues.length; a++) {
                                    if (valueBetweenFingersAns.size() <= LValues[a].length) {

                                        for (int b = 0; b < valueBetweenFingersAns.size(); b++) {
                                            if (valueBetweenFingersAns.get(b) <= (LValues[a][b] + 20) && valueBetweenFingersAns.get(b) >= (LValues[a][b] - 20)) {
                                                alphabetValues[i] = "L";

                                            }
                                            else {
                                                alphabetValues[i] = "D";
                                                break;
                                            }
                                        }

                                    }
                                }
                            }

                            if (same == true && alphabetValues[i].equals("B")) {
                                if(valueFingersAns.size() == 2){
                                    alphabetValues[i] = "Y";
                                }

                            }
                            if (same == true && alphabetValues[i].equals("Y")) {
                                if(valueFingersAns.get(1) - valueFingersAns.get(0) >= 15 ){
                                    alphabetValues[i] = "I";
                                }


                            }




                            if (same == true) {
                                Toast.makeText(SignToSpeechActivity.this," "+ alphabetValues[i], Toast.LENGTH_SHORT).show();
                                t1.speak(alphabetValues[i], TextToSpeech.QUEUE_FLUSH, null);
                                break;
                            }
                        }



                    }

                });
            }
            else if(timer>30)
                timer = 0;

            timer++;
            return mRgba;


        }

    }


