package app.com.gradapplication;

import android.content.Intent;
import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.speech.RecognizerIntent;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Locale;

public class SpeechToSignActivity extends AppCompatActivity {

    ImageView back, sign, signImage;

    TextView txtView;

    ArrayList<String> result = null;

    ImageView mic, wp, more;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_speech_to_sign);

        back = (ImageView) findViewById(R.id.back);
        sign = (ImageView) findViewById(R.id.sign);
        signImage = (ImageView) findViewById(R.id.sign_image);

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        sign.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(SpeechToSignActivity.this, SignToSpeechActivity.class);
                startActivity(intent);
            }
        });

        txtView  = (TextView) findViewById(R.id.answer);

        mic = (ImageView) findViewById(R.id.mic);





        mic.setOnClickListener(new View.OnClickListener() {

            @Override

            public void onClick(View v) {

                Toast.makeText(v.getContext(),"Say Something...",Toast.LENGTH_SHORT).show();

                Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);

                intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);

                intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());

                if(intent.resolveActivity(getPackageManager())!=null) {

                    startActivityForResult(intent, 5);

                }

                else {

                    Toast.makeText(v.getContext(),"Your Device Doesn't Support Speech Intent", Toast.LENGTH_SHORT).show();

                }

            }
        });



        }

    @Override

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        super.onActivityResult(requestCode, resultCode, data);



        if(requestCode==5) {

            if(resultCode==RESULT_OK && data!=null) {

                result = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);

                txtView.setText(result.get(0));

                if (txtView.getText().equals("B")||txtView.getText().equals("b"))
                {
                    signImage.setImageResource(R.drawable.letterb);
                }
                else if (txtView.getText().equals("D") ||txtView.getText().equals("d") )
                {
                    signImage.setImageResource(R.drawable.letterd);
                }

                else if (txtView.getText().equals("F") ||txtView.getText().equals("f") )
                {
                    signImage.setImageResource(R.drawable.letterf);
                }

                else if (txtView.getText().equals("I") ||txtView.getText().equals("i") )
                {
                    signImage.setImageResource(R.drawable.letteri);
                }
                else if (txtView.getText().equals("L") ||txtView.getText().equals("l") )
                {
                    signImage.setImageResource(R.drawable.letterl);
                }
                else if (txtView.getText().equals("V") ||txtView.getText().equals("v") )
                {
                    signImage.setImageResource(R.drawable.letterv);
                }
                else if (txtView.getText().equals("Y") ||txtView.getText().equals("y") || txtView.getText().equals("why") )
                {
                    signImage.setImageResource(R.drawable.lettery);
                }

                else {
                    signImage.setVisibility(View.GONE);
                }

            }

        }

    }


}
